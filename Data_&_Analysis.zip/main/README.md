# Computational-mechanisms-underlying-partisan-information-processing
De-identified raw data and code for manuscript entitled computational mechanisms underlying partisan information processing biases and associations with depth of cognitive reasoning
